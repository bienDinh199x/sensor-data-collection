function checkInputAlarm(id_lowerAlarm, id_lowerWarning, id_upperWarning, id_upperAlarm, return_alert, return_chart) {

  var array = []
  var lowerAlarm1 = $(id_lowerAlarm).val()
  if (lowerAlarm1 !== '') {
    lowerAlarm1 = lowerAlarm1 * 1
    array.push(lowerAlarm1)
  }

  var lowerWarning1 = $(id_lowerWarning).val()
  if (lowerWarning1 !== '') {
    lowerWarning1 = lowerWarning1 * 1
    array.push(lowerWarning1)
  }

  var upperWarning1 = $(id_upperWarning).val()
  if (upperWarning1 !== '') {
    upperWarning1 = upperWarning1 * 1
    array.push(upperWarning1)
  }

  var upperAlarm1 = $(id_upperAlarm).val()
  if (upperAlarm1 !== '') {
    upperAlarm1 = upperAlarm1 * 1
    array.push(upperAlarm1)
  }
  if (lowerAlarm1 < -8388600 || lowerAlarm1 > 8388600) {
    $(return_alert).html(`Lower alarm value out of limit<br>-8388600 < lower Alarm < 8388600`)
    return false
  }
  if (lowerWarning1 < -8388600 || lowerWarning1 > 8388600) {
    $(return_alert).html(`Lower warning value out of limit<br>-8388600 < lower Alarm < 8388600`)
    return false
  }
  if (upperWarning1 < -8388600 || upperWarning1 > 8388600) {
    $(return_alert).html(`Upper warning value out of limit<br>-8388600 < lower Alarm < 8388600`)
    return false
  }
  if (upperAlarm1 < -8388600 || upperAlarm1 > 8388600) {
    $(return_alert).html(`Upper alarm value out of limit<br>-8388600 < lower Alarm < 8388600`)
    return false
  }
  for (let i = 0; i < array.length - 1; i++) {
    if (array[i] > array[i + 1]) {
      $(return_alert).html(`${array[i]} > ${array[i + 1]}`)
      return false
    }
  }

  $(return_alert).html('')

  $(return_chart).html(alarmWarning(lowerAlarm1 + '', lowerWarning1 + '', upperWarning1 + '', upperAlarm1 + ''))

  return true
}





function alarmWarning(lowerAlarm1, lowerWarning1, upperWarning1, upperAlarm1) { // Vẽ biểu đồ
  var up_down_tooltip = 0
  var max = ''
  var min = ''
  if (lowerAlarm1 !== '') {
    max = lowerAlarm1
    min = lowerAlarm1
  }

  if (lowerWarning1 !== '') {
    if (max == '' || max * 1 < lowerWarning1 * 1) {
      max = lowerWarning1 * 1
    }
    if (min == '') {
      min = lowerWarning1 * 1
    }
  }

  if (upperWarning1 !== '') {
    if (max == '' || max * 1 < upperWarning1 * 1) {
      max = upperWarning1 * 1
    }
    if (min == '') {
      min = upperWarning1 * 1
    }
  }

  if (upperAlarm1 !== '') {
    if (max == '' || max * 1 < upperAlarm1 * 1) {
      max = upperAlarm1 * 1
    }
    if (min == '') {
      min = upperAlarm1 * 1
    }
  }

  var colorK1 = 'w3-green'
  var colorK5 = 'w3-green'

  if (lowerAlarm1 == '') {
    lowerAlarm = min
    lowerAlarmHTML = ``
  } else {
    lowerAlarm = lowerAlarm1
    colorK1 = "w3-red"
    if (up_down_tooltip == 1) {
      lowerAlarmHTML = `<div class="tooltip" style="margin-top: 9px; margin-left: -36px;">
                <span class="tooltiptext tooltip-bottom"><b>&nbsp;${lowerAlarm1}&nbsp;</b></span>
            </div>`
    } else {
      lowerAlarmHTML = `<div class="tooltip" style="margin-top: -6px; margin-left: -40px;">
                <span class="tooltiptext tooltip-top"><b>&nbsp;${lowerAlarm1}&nbsp;</b></span>
            </div>`
    }
    up_down_tooltip = 1 - up_down_tooltip
  }

  if (lowerWarning1 == '') {
    lowerWarning = lowerAlarm
    lowerWarningHTML = ``
  } else {
    lowerWarning = lowerWarning1
    if (colorK1 == 'w3-green') {
      colorK1 = "w3-yellow"
    }

    if (up_down_tooltip == 1) {
      lowerWarningHTML = `<div class="tooltip" style="margin-top: 9px; margin-left: -36px;">
                <span class="tooltiptext tooltip-bottom"><b>&nbsp;${lowerWarning1}&nbsp;</b></span>
            </div>`
    } else {
      lowerWarningHTML = `<div class="tooltip" style="margin-top: -6px; margin-left: -40px;">
                <span class="tooltiptext tooltip-top"><b>&nbsp;${lowerWarning1}&nbsp;</b></span>
            </div>`
    }
    up_down_tooltip = 1 - up_down_tooltip
  }

  if (upperAlarm1 == '') {
    upperAlarm = max
    upperAlarmHTML = ``
  } else {
    upperAlarm = upperAlarm1
    colorK5 = "w3-red"
    if (up_down_tooltip == 1) {
      upperAlarmHTML = `<div class="tooltip" style="margin-top: 9px; margin-left: -36px;">
                <span class="tooltiptext tooltip-bottom"><b>&nbsp;${upperAlarm1}&nbsp;</b></span>
            </div>`
    } else {
      upperAlarmHTML = `<div class="tooltip" style="margin-top: -6px; margin-left: -40px;">
                <span class="tooltiptext tooltip-top"><b>&nbsp;${upperAlarm1}&nbsp;</b></span>
            </div>`
    }
    up_down_tooltip = 1 - up_down_tooltip

  }

  if (upperWarning1 == '') {
    upperWarning = upperAlarm
    upperWarningHTML = ``
  } else {
    upperWarning = upperWarning1
    if (colorK5 == 'w3-green') {
      colorK5 = "w3-yellow"
    }
    if (up_down_tooltip == 1) {
      upperWarningHTML = `<div class="tooltip" style="margin-top: 9px; margin-left: -36px;">
                <span class="tooltiptext tooltip-bottom"><b>&nbsp;${upperWarning1}&nbsp;</b></span>
            </div>`
    } else {
      upperWarningHTML = `<div class="tooltip" style="margin-top: -6px; margin-left: -40px;">
                <span class="tooltiptext tooltip-top"><b>&nbsp;${upperWarning1}&nbsp;</b></span>
            </div>`
    }
    up_down_tooltip = 1 - up_down_tooltip
  }
  K1 = lowerAlarm - min + 20
  K2 = lowerWarning - lowerAlarm
  K3 = upperWarning - lowerWarning
  K4 = upperAlarm - upperWarning
  K5 = max * 1 + 20 - upperAlarm * 1
  total = K1 + K2 + K3 + K4 + K5
  return `<div class="w3-row">
        <div class="w3-col line ${colorK1}" style="width:${K1 * 100 / total}%;"></div>
        <div class="w3-col line w3-yellow" style="width:${K2 * 100 / total}%;">${lowerAlarmHTML}</div>
        <div class="w3-col line w3-green" style="width:${K3 * 100 / total}%;">${lowerWarningHTML}</div>
        <div class="w3-col line w3-yellow" style="width:${K4 * 100 / total}%;">${upperWarningHTML}</div>
        <div class="w3-col line ${colorK5}" style="width:${K5 * 100 / total}%;">${upperAlarmHTML}</div>
    </div>`
}