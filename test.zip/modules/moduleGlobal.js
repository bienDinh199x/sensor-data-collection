module.exports = ``

global.common = require('../helpers/common.js')
global.config = require('../config/config.js')

global.listSensor = {}
global.utc0Time