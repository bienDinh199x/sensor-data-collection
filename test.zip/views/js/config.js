var config = {
 chart: {
  maxLength: 200
 }
}