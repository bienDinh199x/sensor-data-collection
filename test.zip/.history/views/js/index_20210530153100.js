var listCom = '',
  jsonSensor = [],
  flagModeChart = 1,
  flagDetail = '',
  flagViewDetail = false,
  flagCountChart = 0,

  flagStart0 = false,
  numChart0 = 0,

  flagSelectSensor0,
  flagSelectSensor1,
  flagSelectSensor2,



  flagSensor = 0,
  flagChart = [{
    count: 0,
    numChart: 0,
    start: false
  },
  {
    count: 0,
    numChart: 0,
    start: false
  },
  {
    count: 0,
    numChart: 0,
    start: false
  }
  ],

  chart = [],


  defineLineChart = {
    labels: [],
    datasets: [{
      label: 'Lần 1',
      backgroundColor: '#3F51B5',
      borderColor: '#3F51B5',
      data: []
    },
    {
      label: 'Lần 2',
      backgroundColor: '#F44336',
      borderColor: '#F44336',
      data: []
    },
    {
      label: 'Lần 3',
      backgroundColor: '#4CAF50',
      borderColor: '#4CAF50',
      data: []
    }
    ]
  };

$(document).ready(() => {
  console.info(`Start index page`)
  socket = io()
  socket.on('connect', () => {
    console.info(`Index connect socketIO`)
  })
  socket.on(`list_com`, (json) => {
    listCom = json
  })

  socket.on(`list`, (json) => {
    jsonSensor = json
    funViewList()
  })

  socket.on(`data`, (json) => {
    index_of(jsonSensor, `key`, json.key, (i) => {
      jsonSensor[i] = json
    })


    funViewMain(json)
  })


  start()
})
/*
 ######  ########    ###    ########  ########
##    ##    ##      ## ##   ##     ##    ##
##          ##     ##   ##  ##     ##    ##
 ######     ##    ##     ## ########     ##
      ##    ##    ######### ##   ##      ##
##    ##    ##    ##     ## ##    ##     ##
 ######     ##    ##     ## ##     ##    ##
*/

function start() {
  formInfoChart()
  socket.emit(`list`)
  setInterval(() => { timer() }, 5000)
}
function timer() {
  funViewList()
}



/*
##       ####  ######  ########
##        ##  ##    ##    ##
##        ##  ##          ##
##        ##   ######     ##
##        ##        ##    ##
##        ##  ##    ##    ##
######## ####  ######     ##
*/

function funViewList() { // list sensor
  var html = ``
  if (jsonSensor.length > 0) {
    for (var i = 0; i < jsonSensor.length; i++) {
      console.log(jsonSensor);
      detailStatus(jsonSensor[i].time, jsonSensor[i].unit_time, (str, status) => {
        let badge = `style="display:none">`
        if (jsonSensor[i].key == flagChart[0].key) { badge = `>*` }
        if (jsonSensor[i].key == flagChart[1].key) { badge = `>1` }
        if (jsonSensor[i].key == flagChart[2].key) { badge = `>2` }
        html += `
        <div id="${jsonSensor[i].key}" class="w3-button w3-card w3-border w3-hover-border-red w3-round sensor ${status}" onclick="detail('${jsonSensor[i].key}')">
          <div class="w3-badge w3-deep-orange" ${badge}</div>
          <div class="icon_val">
            <div class="icon" style="background: transparent url('../images/${jsonSensor[i].type}.png') 0 0/100% 100% no-repeat;"></div>
            <span class="val">${jsonSensor[i].val}</span><sup class="unit">${jsonSensor[i].unit}</sup>
          </div>
          <div class="sensor_info">
            <div class="info">
            <b>${jsonSensor[i].type}</b><br>
            ${jsonSensor[i].no}
            </div>
            <div class="sensor_status">${str}</div>
          </div>
        </div>
        <div class="btn_menu w3-button w3-round w3-border w3-white"><i class="fas fa-bars"></i></div>`

      })
    }
  }
  $(`#mySidebar`).html(html)
}

function detailStatus(str, unit_time, done) {
  time_string((_str, now) => {
    if (now - unit_time > 5000) {
      return done(str, `w3-light-gray`)
    } else {
      return done(`Connected`, `w3-green`)
    }
  })
}

function funViewMain(json) {
  $(`#${json.type}_${json.no} .val`).html(json.val)
  $(`#${json.type}_${json.no} .unit`).html(json.unit)
  $(`#${json.type}_${json.no} .sensor_status`).html(`Connected`)
  $(`#${json.type}_${json.no}`).removeClass(`w3-light-gray`)
  $(`#${json.type}_${json.no}`).addClass(`w3-green`)

  var x = -1

  if (json.key == flagChart[0].key) {
    x = 0
  } else if (json.key == flagChart[1].key) {
    x = 1
  } else if (json.key == flagChart[2].key) {
    x = 2
  }
  if (x > -1) {
    $(`#mode_chart_1 .time`).html(`${json.time}`)
    $(`#mode_chart_1 .val span`).html(json.val)
    $(`#mode_chart_1 .val sup`).html(json.unit)
    $(`#mode_chart_1 .icon`).html(`<div style="background: transparent url('./images/${json.type}.png') 0 0/100% 100% no-repeat; height: 100%; width: 100%;"></div>`)
    if (flagChart[x].start) {
      addDataChart(x, json)
    }
  }
}

/*
 
 ########  ######## ########    ###    #### ##       
 ##     ## ##          ##      ## ##    ##  ##       
 ##     ## ##          ##     ##   ##   ##  ##       
 ##     ## ######      ##    ##     ##  ##  ##       
 ##     ## ##          ##    #########  ##  ##       
 ##     ## ##          ##    ##     ##  ##  ##       
 ########  ########    ##    ##     ## #### ######## 
 
*/
function detail(key) {



  index_of(jsonSensor, `key`, key, (i) => {
    creatChart(flagSensor)
    json = jsonSensor[i]
    flagChart[flagSensor].key = key
    $(`#info_chart_${flagSensor} .name`).html(`${json.type} (${json.no})`)
    $(`#info_chart_${flagSensor} .time`).html(`${json.time}`)
    $(`#info_chart_${flagSensor} .val span`).html(json.val)
    $(`#info_chart_${flagSensor} .val sup`).html(json.unit)
    funViewList()
  })

}


function viewInfo() {
  $(`#popup`).show()
  $(`#popup header>div`).html('Info')
  $(`#popup nav`).html(listCom)

  var arr = listCom.split(`,`)
  if (arr.length > 0) {
    for (var i = 0; i < arr.length; i++) {
      arr[i]
    }
  }
}

/*
 ######  ##     ##    ###    ########  ########
##    ## ##     ##   ## ##   ##     ##    ##
##       ##     ##  ##   ##  ##     ##    ##
##       ######### ##     ## ########     ##
##       ##     ## ######### ##   ##      ##
##    ## ##     ## ##     ## ##    ##     ##
 ######  ##     ## ##     ## ##     ##    ##
*/
function modeChart() {
  flagModeChart = 3 - flagModeChart
  if (flagModeChart == 1) {
    funSelectChart(0)
    $(`#mode_chart_1`).show();
    $(`#mode_chart_2`).hide();
  } else {
    funSelectChart(1)
    $(`#mode_chart_1`).hide();
    $(`#mode_chart_2`).show();
  }
}




function creatChart() {




  flagCountChart = 0

  const config = {
    type: 'line',
    data: JSON.parse(JSON.stringify(defineLineChart)),
    options: {
      scales: {
        y: {
          min: 0,
          ticks: {
            stepSize: 5
          }
        }
      }
    }
  };


  // $(`#view_chart_${flagSensor}`).html(`<canvas id="chart_${flagSensor}" width="${$(`#chart_${flagSensor}`).width()}" height="${$(`#chart_${flagSensor}`).height()}"></canvas>`)
  $(`#view_chart_${flagSensor} .view_chart`).html(`<canvas id="chart_${flagSensor}" width="${$(`#view_chart_${flagSensor} .view_chart`).width()}" height="${$(`#view_chart_${flagSensor} .view_chart`).height()}"></canvas>`)

  chart[flagSensor] = new Chart(
    document.getElementById(`chart_${flagSensor}`),
    config
  );

  flagViewDetail = true
}


function addDataChart(x, json) {
  console.log(flagChart[x]);
  flagChart[x].count++;
  chart[x].data.labels[flagChart[x].count] = flagChart[x].count;
  chart[x].data.datasets[flagChart[x].numChart].data[flagChart[x].count] = json.val;
  console.log(chart[x].data.datasets[flagChart[x].numChart]);
  chart[x].update();
}

function newChart(x) {
  let numChart = $(`#control span`).html() * 1 + 1
  flagCountChart = 0
  $(`#control span`).html(numChart)
  if (numChart == 3) {
    $(`#btn_new`).hide()
  }
}

function startChart(x, command) {
  flagChart[x].start = command
  if (command) {
    $(`#info_chart_${x} .w3-green`).hide()
    $(`#info_chart_${x} .w3-red`).show()
  } else {
    $(`#info_chart_${x} .w3-green`).show()
    $(`#info_chart_${x} .w3-red`).hide()
  }
}

function addChart(x) {
  switch (x) {
    case 0:
      numChart0++
      flagCountChart = 0
      if (numChart0 > 1) {
        $(`#info_chart_${x} .w3-white`).hide()
      }
      break;
  }
}


function formInfoChart() {
  for (let i = 0; i < 3; i++) {

    $(`#info_chart_${i}`).html(`
    <div class="w3-badge w3-deep-orange w3-xlarge" style="position: absolute; right: 4px;width: 36px;margin-top: -11px;" onclick="funSelectChart(${i})">${i == 0 ? '*' : i}</div>
      <div class="icon"></div>
      <div class="val"><span></span><sup></sup></div>
      <div class="time"></div>
      <div class="name"></div>
      <div class="">
        <div class="butonChart">
          <button class="w3-btn w3-round-large w3-green" onclick="startChart(${i},true)"><i class="fas fa-play-circle"></i> Start</button>
        </div>
        <div class="butonChart">
          <button class="w3-btn w3-round-large w3-red" onclick="startChart(${i},false)" style="display: none"><i class="fas fa-stop-circle"></i> Stop</button>
        </div>

        <div class="butonChart">
          <button class="w3-btn w3-round-large w3-yellow" onclick="clearChart(${i})"><i class="fas fa-minus-circle"></i> Clear</button>
        </div>

        <div class="butonChart">
          <button class="w3-btn w3-round-large w3-white" onclick="addChart(${i})"><i class="fas fa-plus-circle"></i> New chart</button>
        </div>
      </div>
    `)
  }
}

function funSelectChart(x) {
  flagSensor = x
  $(`.chart>div`).removeClass(`w3-border-red`)
  $(`#view_chart_${x}>div`).addClass(`w3-border-red`)
}