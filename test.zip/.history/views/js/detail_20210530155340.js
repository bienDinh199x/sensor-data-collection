
/*
 ########  ######## ########    ###    #### ##       
 ##     ## ##          ##      ## ##    ##  ##       
 ##     ## ##          ##     ##   ##   ##  ##       
 ##     ## ######      ##    ##     ##  ##  ##       
 ##     ## ##          ##    #########  ##  ##       
 ##     ## ##          ##    ##     ##  ##  ##       
 ########  ########    ##    ##     ## #### ######## 
*/
function detail(key) {
  index_of(jsonSensor, `key`, key, (i) => {
    creatChart(flagSensor)
    json = jsonSensor[i]
    flagChart[flagSensor].key = key
    $(`#info_chart_${flagSensor} .name`).html(`${json.type} (${json.no})`)
    $(`#info_chart_${flagSensor} .time`).html(`${json.time}`)
    $(`#info_chart_${flagSensor} .val span`).html(json.val)
    $(`#info_chart_${flagSensor} .val sup`).html(json.unit)
    listSensor()
  })

}
