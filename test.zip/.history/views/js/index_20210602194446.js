var listCom = '',
  jsonSensor = [],
  flagModeChart = 1,
  flagDetail = '',
  flagViewDetail = false,
  flagCountChart = 0,

  flagStart0 = false,
  numChart0 = 0,

  flagSelectSensor0,
  flagSelectSensor1,
  flagSelectSensor2,



  flagDetail = 0,
  flagChart = [{
    count: 0,
    numChart: 0,
    start: false
  },
  {
    count: 0,
    numChart: 0,
    start: false
  },
  {
    count: 0,
    numChart: 0,
    start: false
  }
  ],

  chart = [],


  defineLineChart = {
    labels: [],
    datasets: [{
      label: 'Lần 1',
      backgroundColor: '#3F51B5',
      borderColor: '#3F51B5',
      data: []
    },
    {
      label: 'Lần 2',
      backgroundColor: '#F44336',
      borderColor: '#F44336',
      data: []
    },
    {
      label: 'Lần 3',
      backgroundColor: '#4CAF50',
      borderColor: '#4CAF50',
      data: []
    }
    ]
  };

$(document).ready(() => {
  console.info(`Start index page`)
  socket = io()
  socket.on('connect', () => {
    console.info(`Index connect socketIO`)
  })
  socket.on(`list_com`, (json) => {
    listCom = json
  })

  socket.on(`list`, (json) => {
    jsonSensor = json
    listSensor()
  })

  socket.on(`data`, (json) => { // cập nhật sensor
    index_of(jsonSensor, `key`, json.key, (i) => {
      time_string((str, now) => {
        json.unit_time = now
        json.time = str
      })


      jsonSensor[i] = json
    })
    updateListSensor(json)
    //funViewMain(json)
  })


  start()
})
/*
 ######  ########    ###    ########  ########
##    ##    ##      ## ##   ##     ##    ##
##          ##     ##   ##  ##     ##    ##
 ######     ##    ##     ## ########     ##
      ##    ##    ######### ##   ##      ##
##    ##    ##    ##     ## ##    ##     ##
 ######     ##    ##     ## ##     ##    ##
*/

function start() {
  formInfoChart()
  socket.emit(`list`)
  setInterval(() => { timer() }, 5000)
}
function timer() {
  listSensor()
}


function viewInfo() {
  $(`#popup`).show()
  $(`#popup header>div`).html('Info')
  $(`#popup nav`).html(listCom)

  var arr = listCom.split(`,`)
  if (arr.length > 0) {
    for (var i = 0; i < arr.length; i++) {
      arr[i]
    }
  }
}

/*
 ######  ##     ##    ###    ########  ########
##    ## ##     ##   ## ##   ##     ##    ##
##       ##     ##  ##   ##  ##     ##    ##
##       ######### ##     ## ########     ##
##       ##     ## ######### ##   ##      ##
##    ## ##     ## ##     ## ##    ##     ##
 ######  ##     ## ##     ## ##     ##    ##
*/
function modeChart() {
  flagModeChart = 3 - flagModeChart
  if (flagModeChart == 1) {
    funSelectChart(0)
    $(`#mode_chart_1`).show();
    $(`#mode_chart_2`).hide();
  } else {
    funSelectChart(1)
    $(`#mode_chart_1`).hide();
    $(`#mode_chart_2`).show();
  }
}




function creatChart() {




  flagCountChart = 0

  const config = {
    type: 'line',
    data: JSON.parse(JSON.stringify(defineLineChart)),
    options: {
      scales: {
        y: {
          min: 0,
          ticks: {
            stepSize: 5
          }
        }
      }
    }
  };


  // $(`#view_chart_${flagDetail}`).html(`<canvas id="chart_${flagDetail}" width="${$(`#chart_${flagDetail}`).width()}" height="${$(`#chart_${flagDetail}`).height()}"></canvas>`)
  $(`#view_chart_${flagDetail} .view_chart`).html(`<canvas id="chart_${flagDetail}" width="${$(`#view_chart_${flagDetail} .view_chart`).width()}" height="${$(`#view_chart_${flagDetail} .view_chart`).height()}"></canvas>`)

  chart[flagDetail] = new Chart(
    document.getElementById(`chart_${flagDetail}`),
    config
  );

  flagViewDetail = true
}


function addDataChart(x, json) {
  console.log(flagChart[x]);
  flagChart[x].count++;
  chart[x].data.labels[flagChart[x].count] = flagChart[x].count;
  chart[x].data.datasets[flagChart[x].numChart].data[flagChart[x].count] = json.val;
  console.log(chart[x].data.datasets[flagChart[x].numChart]);
  chart[x].update();
}

function newChart(x) {
  let numChart = $(`#control span`).html() * 1 + 1
  flagCountChart = 0
  $(`#control span`).html(numChart)
  if (numChart == 3) {
    $(`#btn_new`).hide()
  }
}

function startChart(x, command) {
  flagChart[x].start = command
  if (command) {
    $(`#info_chart_${x} .w3-green`).hide()
    $(`#info_chart_${x} .w3-red`).show()
  } else {
    $(`#info_chart_${x} .w3-green`).show()
    $(`#info_chart_${x} .w3-red`).hide()
  }
}

function addChart(x) {
  switch (x) {
    case 0:
      numChart0++
      flagCountChart = 0
      if (numChart0 > 1) {
        $(`#info_chart_${x} .w3-white`).hide()
      }
      break;
  }
}


function formInfoChart() {
  for (let i = 0; i < 3; i++) {

    $(`#info_chart_${i}`).html(`
    <div class="w3-badge w3-deep-orange w3-xlarge" style="position: absolute; right: 4px;width: 36px;margin-top: -11px;" onclick="funSelectChart(${i})">${i == 0 ? '*' : i}</div>
      <div class="icon"></div>
      <div class="val"><span></span><sup></sup></div>
      <div class="time"></div>
      <div class="name"></div>
      <div class="">
        <div class="butonChart">
          <button class="w3-btn w3-round-large w3-green" onclick="startChart(${i},true)"><i class="fas fa-play-circle"></i> Start</button>
        </div>
        <div class="butonChart">
          <button class="w3-btn w3-round-large w3-red" onclick="startChart(${i},false)" style="display: none"><i class="fas fa-stop-circle"></i> Stop</button>
        </div>

        <div class="butonChart">
          <button class="w3-btn w3-round-large w3-yellow" onclick="clearChart(${i})"><i class="fas fa-minus-circle"></i> Clear</button>
        </div>

        <div class="butonChart">
          <button class="w3-btn w3-round-large w3-white" onclick="addChart(${i})"><i class="fas fa-plus-circle"></i> New chart</button>
        </div>
      </div>
    `)
  }
}

function funSelectChart(x) {
  flagDetail = x
  $(`.chart>div`).removeClass(`w3-border-red`)
  $(`#view_chart_${x}>div`).addClass(`w3-border-red`)
}