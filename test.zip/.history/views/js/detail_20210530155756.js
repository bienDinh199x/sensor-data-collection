
/*
 ########  ######## ########    ###    #### ##       
 ##     ## ##          ##      ## ##    ##  ##       
 ##     ## ##          ##     ##   ##   ##  ##       
 ##     ## ######      ##    ##     ##  ##  ##       
 ##     ## ##          ##    #########  ##  ##       
 ##     ## ##          ##    ##     ##  ##  ##       
 ########  ########    ##    ##     ## #### ######## 
*/
function detail(key) {
  index_of(jsonSensor, `key`, key, (i) => {
    creatChart(flagDetail)
    json = jsonSensor[i]
    flagChart[flagDetail].key = key
    $(`#info_chart_${flagDetail} .name`).html(`${json.type} (${json.no})`)
    $(`#info_chart_${flagDetail} .time`).html(`${json.time}`)
    $(`#info_chart_${flagDetail} .val span`).html(json.val)
    $(`#info_chart_${flagDetail} .val sup`).html(json.unit)
    listSensor()
  })

}
