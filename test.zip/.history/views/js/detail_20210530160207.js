
/*
 ########  ######## ########    ###    #### ##       
 ##     ## ##          ##      ## ##    ##  ##       
 ##     ## ##          ##     ##   ##   ##  ##       
 ##     ## ######      ##    ##     ##  ##  ##       
 ##     ## ##          ##    #########  ##  ##       
 ##     ## ##          ##    ##     ##  ##  ##       
 ########  ########    ##    ##     ## #### ######## 
*/
function detail(key) {
  index_of(jsonSensor, `key`, key, (i) => {
    creatChart(flagDetail)
    json = jsonSensor[i]
    flagChart[flagDetail].key = key
    $(`#info_chart_${flagDetail} .name`).html(`${json.type} (${json.no})`)
    $(`#info_chart_${flagDetail} .time`).html(`${json.time}`)
    $(`#info_chart_${flagDetail} .val span`).html(json.val)
    $(`#info_chart_${flagDetail} .val sup`).html(json.unit)
    listSensor()
  })
}

function updateDetail(json) {
  var x = -1
  if (json.key == flagChart[0].key) { x = 0 }
  else if (json.key == flagChart[1].key) { x = 1 }
  else if (json.key == flagChart[2].key) { x = 2 }

  if (x > -1) {
    $(`#info_chart_${x} .time`).html(`${json.time}`)
    $(`#info_chart_${x} .val span`).html(json.val)
    $(`#info_chart_${x} .val sup`).html(json.unit)
    $(`#info_chart_${x} .icon`).html(`<div style="background: transparent url('./images/${json.type}.png') 0 0/100% 100% no-repeat; height: 100%; width: 100%;"></div>`)
    if (flagChart[x].start) {
      addDataChart(x, json)
    }
  }
}