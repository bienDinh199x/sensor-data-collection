/*
##       ####  ######  ########
##        ##  ##    ##    ##
##        ##  ##          ##
##        ##   ######     ##
##        ##        ##    ##
##        ##  ##    ##    ##
######## ####  ######     ##
*/

function listSensor() { // list sensor
  var html = ``
  if (jsonSensor.length > 0) {
    for (var i = 0; i < jsonSensor.length; i++) {
      console.log(jsonSensor);
      statusSensor(jsonSensor[i].time, jsonSensor[i].unit_time, (str, status) => {
        let badge = `style="display:none">`
        if (jsonSensor[i].key == flagChart[0].key) { badge = `>*` }
        if (jsonSensor[i].key == flagChart[1].key) { badge = `>1` }
        if (jsonSensor[i].key == flagChart[2].key) { badge = `>2` }
        html += `
        <button id="${jsonSensor[i].key}" class="w3-button w3-card w3-border w3-hover-border-red w3-round sensor w3-${status} w3-hover-${status}" onclick="detail('${jsonSensor[i].key}')">
          <div class="w3-badge w3-deep-orange" ${badge}</div>
          <div class="icon_val">
            <div class="icon" style="background: transparent url('../images/${jsonSensor[i].type}.png') 0 0/100% 100% no-repeat;"></div>
            <span class="val">${jsonSensor[i].val}</span><sup class="unit">${jsonSensor[i].unit}</sup>
          </div>
          <div class="sensor_info">
            <div class="info">
            <b>${jsonSensor[i].type}</b><br>
            ${jsonSensor[i].no}
            </div>
            <div class="sensor_status">${str}</div>
          </div>
        </button>
        <div class="btn_menu w3-button w3-round w3-border w3-white"><i class="fas fa-bars"></i></div>`

      })
    }
  }
  $(`#mySidebar`).html(html)
}

function statusSensor(str, unit_time, done) {
  time_string((_str, now) => {
    if (now - unit_time > 5000) {
      return done(str, `light-gray`)
    } else {
      return done(`Connected`, `green`)
    }
  })
}

function updateListSensor(json) {
  $(`#${json.type}_${json.no} .val`).html(json.val)
  $(`#${json.type}_${json.no} .unit`).html(json.unit)
  $(`#${json.type}_${json.no} .sensor_status`).html(`Connected`)
  $(`#${json.type}_${json.no}`).removeClass(`w3-light-gray w3-hover-light-gray`)
  $(`#${json.type}_${json.no}`).addClass(`w3-green w3-hover-green`)

  var x = -1

  if (json.key == flagChart[0].key) {
    x = 0
  } else if (json.key == flagChart[1].key) {
    x = 1
  } else if (json.key == flagChart[2].key) {
    x = 2
  }
  if (x > -1) {
    $(`#mode_chart_1 .time`).html(`${json.time}`)
    $(`#mode_chart_1 .val span`).html(json.val)
    $(`#mode_chart_1 .val sup`).html(json.unit)
    $(`#mode_chart_1 .icon`).html(`<div style="background: transparent url('./images/${json.type}.png') 0 0/100% 100% no-repeat; height: 100%; width: 100%;"></div>`)
    if (flagChart[x].start) {
      addDataChart(x, json)
    }
  }
}
