var listCom = '',
  jsonSensor = [],
  flagModeChart = 1,
  flagDetail = '',
  flagViewDetail = false,
  flagCountChart = 0,

  flagStart0 = false,
  numChart0 = 0,

  flagSelectSensor0,
  flagSelectSensor1,
  flagSelectSensor2,



  flagSensor = 0,
  flagChart = [{
    count: 0,
    numChart: 0,
    start: false
  },
  {
    count: 0,
    numChart: 0,
    start: false
  },
  {
    count: 0,
    numChart: 0,
    start: false
  }
  ],

  chart = [],


  defineLineChart = {
    labels: [],
    datasets: [{
      label: 'Lần 1',
      backgroundColor: '#3F51B5',
      borderColor: '#3F51B5',
      data: []
    },
    {
      label: 'Lần 2',
      backgroundColor: '#F44336',
      borderColor: '#F44336',
      data: []
    },
    {
      label: 'Lần 3',
      backgroundColor: '#4CAF50',
      borderColor: '#4CAF50',
      data: []
    }
    ]
  };

$(document).ready(() => {
  console.info(`Start index page`)
  socket = io()
  socket.on('connect', () => {
    console.info(`Index connect socketIO`)
  })
  socket.on(`list_com`, (json) => {
    listCom = json
  })

  socket.on(`list`, (json) => {
    jsonSensor = json
    funViewList()
  })

  socket.on(`data`, (json) => {
    funViewMain(json)
  })


  start()
})
/*
 ######  ########    ###    ########  ########
##    ##    ##      ## ##   ##     ##    ##
##          ##     ##   ##  ##     ##    ##
 ######     ##    ##     ## ########     ##
      ##    ##    ######### ##   ##      ##
##    ##    ##    ##     ## ##    ##     ##
 ######     ##    ##     ## ##     ##    ##
*/

function start() {
  socket.emit(`list`)
}




/*
##       ####  ######  ########
##        ##  ##    ##    ##
##        ##  ##          ##
##        ##   ######     ##
##        ##        ##    ##
##        ##  ##    ##    ##
######## ####  ######     ##
*/

function funViewList() {
  let json = jsonSensor
  var html = ``
  if (json.length > 0) {
    for (var i = 0; i < json.length; i++) {
      console.log(json);
      detailStatus(json[i].time, json[i].unit_time, (str, status) => {
        let badge = `style="display:none">`
        if (json[i].key == flagSelectSensor0) {
          badge = `>*`
        }
        if (json[i].key == flagSelectSensor1) {
          badge = `>1`
        }
        if (json[i].key == flagSelectSensor2) {
          badge = `>2`
        }
        html += `
        
        <div id="${json[i].type}_${json[i].no}" class="w3-button w3-card w3-light-gray w3-border w3-round sensor ${status}" onclick="detail('${json[i].type}_${json[i].no}')">
          <div class="w3-badge w3-red" ${badge}</div>
          <div class="icon_val">
            <div class="icon" style="background: transparent url('../images/${json[i].type}.png') 0 0/100% 100% no-repeat;"></div>
            <span class="val">${json[i].val}</span><sup class="unit">${json[i].unit}</sup>
          </div>
          <div class="sensor_info">
            <div class="info">
            <b>${json[i].type}</b><br>
            ${json[i].no}
            </div>
            <div class="sensor_status">${str}</div>
          </div>
        </div>
        <div class="btn_menu w3-button w3-round w3-border w3-white"><i class="fas fa-bars"></i></div>`

      })
    }

  }
  $(`#mySidebar`).html(html)
}

function detailStatus(str, unit_time, done) {
  time_string((_str, now) => {
    if (now - unit_time > 5000) {
      return done(str, `disconnect`)
    } else {
      return done(`Connected`, `connect`)
    }
  })
}

function funViewMain(json) {
  $(`#${json.type}_${json.no} .val`).html(json.val)
  $(`#${json.type}_${json.no} .unit`).html(json.unit)
  $(`#${json.type}_${json.no} .sensor_status`).html(json.time)
  if (json.key == flagSelectSensor0) {
    $(`#mode_chart_1 .time`).html(`${json.time}`)
    $(`#mode_chart_1 .val span`).html(json.val)
    $(`#mode_chart_1 .val sup`).html(json.unit)
    $(`#mode_chart_1 .icon`).html(`<div style="background: transparent url('./images/${json.type}.png') 0 0/100% 100% no-repeat; height: 100%; width: 100%;"></div>`)
  }
  if (flagStart0) {
    addDataChart(json)
  }
}

/*
 
 ########  ######## ########    ###    #### ##       
 ##     ## ##          ##      ## ##    ##  ##       
 ##     ## ##          ##     ##   ##   ##  ##       
 ##     ## ######      ##    ##     ##  ##  ##       
 ##     ## ##          ##    #########  ##  ##       
 ##     ## ##          ##    ##     ##  ##  ##       
 ########  ########    ##    ##     ## #### ######## 
 
*/
function detail(key) {



  index_of(jsonSensor, `key`, key, (i) => {
    creatChart(flagSensor)
    json = jsonSensor[i]
    flagChart[flagSensor].key = key
    $(`#info_chart_${flagSensor} .name`).html(`${json.type} (${json.no})`)
    $(`#info_chart_${flagSensor} .time`).html(`${json.time}`)
    $(`#info_chart_${flagSensor} .val span`).html(json.val)
    $(`#info_chart_${flagSensor} .val sup`).html(json.unit)
    funViewList()
  })

}


function viewInfo() {
  $(`#popup`).show()
  $(`#popup header>div`).html('Info')
  $(`#popup nav`).html(listCom)

  var arr = listCom.split(`,`)
  if (arr.length > 0) {
    for (var i = 0; i < arr.length; i++) {
      arr[i]
    }
  }
}

/*
 ######  ##     ##    ###    ########  ########
##    ## ##     ##   ## ##   ##     ##    ##
##       ##     ##  ##   ##  ##     ##    ##
##       ######### ##     ## ########     ##
##       ##     ## ######### ##   ##      ##
##    ## ##     ## ##     ## ##    ##     ##
 ######  ##     ## ##     ## ##     ##    ##
*/
function modeChart() {
  flagModeChart = 3 - flagModeChart
  if (flagModeChart == 1) {
    flagSensor = 0
    $(`#mode_chart_1`).show();
    $(`#mode_chart_2`).hide();
  } else {
    flagSensor = 1
    $(`#mode_chart_1`).hide();
    $(`#mode_chart_2`).show();
  }
}




function creatChart() {




  flagCountChart = 0

  const config = {
    type: 'line',
    data: JSON.parse(JSON.stringify(defineLineChart)),
    options: {
      scales: {
        y: {
          min: 0,
          ticks: {
            stepSize: 5
          }
        }
      }
    }
  };


  // $(`#view_chart_${flagSensor}`).html(`<canvas id="chart_${flagSensor}" width="${$(`#chart_${flagSensor}`).width()}" height="${$(`#chart_${flagSensor}`).height()}"></canvas>`)
  $(`#view_chart_${flagSensor}`).html(`<canvas id="chart_${flagSensor}" width="${$(`#view_chart_${flagSensor}`).width()}" height="${$(`#view_chart_${flagSensor}`).height()}"></canvas>`)

  chart[flagSensor] = new Chart(
    document.getElementById(`chart_${flagSensor}`),
    config
  );

  flagViewDetail = true
}


function addDataChart(json) {
  flagChart[flagSensor].count++;
  chart[flagSensor].data.labels[flagCountChart] = flagCountChart;
  chart[flagSensor].data.datasets[flagChart[flagSensor].numChart].data[flagChart[flagSensor].count] = json.val;
  chart[flagSensor].update();
}

function newChart() {
  let numChart = $(`#control span`).html() * 1 + 1
  flagCountChart = 0
  $(`#control span`).html(numChart)
  if (numChart == 3) {
    $(`#btn_new`).hide()
  }
}

function startChart(x, command) {
  flagStart[x].start = command
  if (command) {
    $(`#info_chart_${x} .w3-green`).hide()
    $(`#info_chart_${x} .w3-red`).show()
  } else {
    $(`#info_chart_${x} .w3-green`).show()
    $(`#info_chart_${x} .w3-red`).hide()
  }
}

function addChart(x) {
  switch (x) {
    case 0:
      numChart0++
      flagCountChart = 0
      if (numChart0 > 1) {
        $(`#info_chart_${x} .w3-white`).hide()
      }
      break;
  }
}