global.list_sensor = []

// NOTE: Khai báo biến toàn cục
var box_id_name = {}, // id + tên tủ 
  total_list_box = [], // danh sách các tủ kết nối trong hệ thống
  total_list_nac = [],
  total_list_io = [],
  total_list_dte = [],
  total_list_facp = [],
  flag_send = 1, // cờ báo trạng thái đường truyền 485 (0: đang truyền + chờ trả về / 1: sẵn sàng truyền lệnh mới)
  flag_time = 0, // cờ báo thời gian truyền lệnh gần nhất theo ms (dùng để tính timeout)
  flag_module = '', // cờ báo module nhận lệnh
  flag_send_key = '', // cờ báo key gửi lệnh

  flag_facp = 0, // cờ báo index board FACP tiếp theo được đọc giá trị
  flag_facp_nac_io = 0, // cờ báo index board tiếp theo được đọc trạng thái

  flag_output_nac_io = [], // cờ ghi trạng thái các output
  flag_output_nac_io_control_key = {}, // cờ ghi các output được điều khiển


  json_control = [],
  list_facp = [],
  json_facp = [],
  list_facp_keys = [],

  json_nac = [],
  list_io = [],
  list_type_sensor = [],
  list_zone_json = [],
  list_zone_array = [],
  list_zone_tree = [],
  list_audio = [],
  list_file_audio = [],
  json_board_status = [],
  json_board_status_temp = [],

  json_alarm = [],

  array_board = [], // mảng các FACP cần hỏi dữ liệu + NAC, IO cần hỏi trạng thái
  array_board_facp = [], // mảng các FACP cần hỏi trạng thái

  str_sensor_type = '[]',
  json_user = [],
  json_dte = [],
  flag_audio = { timems: 86400000 },
  list_mp3_play = [],
  temp_list_mp3_play = [],
  flag_mp3_play = 0,
  xxx = `xxxxxxxxxxxxxxxxxxxx`,
  json_lang = require('./views/json_lang.json'),
  ioClient



// NOTE: Khai báo require module
const logColor = require('./log_color.js'), // Log màu trực quan
  express = require(`express`), //thư viện web server
  app = express(),
  server = require("http").Server(app), // khởi tạo server



  morgan = require(`morgan`), // Log REST API
  compression = require(`compression`), //nén js, css => gzip
  fs = require(`fs`),
  os = require(`os`),






  config = require('./config/config.json'),

  fontawesomeFree = require("@fortawesome/fontawesome-free"),

  common = require('./modules/module_common.js'),
  sensor = require('./modules/module_sensor.js'),


  //////////////////////////
  serialPort = require("serialport"),
  ByteLength = require('@serialport/parser-byte-length');
var SerialPort = serialPort.SerialPort;
var util = require("util"), repl = require("repl");
var listCom = "";
serialPort.list(function (err, ports) {
  ports.forEach(function (port) {
    listCom += ` , ${port.comName}`
    console.log(port.comName);
    //console.log(port.pnpId);
    //console.log(port.manufacturer);
  });
});

////////////////////////////////

global.io = require(`socket.io`)(server)
sensor.list()


console.log(`--------------------`);
console.log(config.rs485.comPort);
console.log(`--------------------`);
var port = new serialPort(config.rs485.comPort, { baudRate: config.rs485.baudRate })

// NOTE: Hứng dữ liệu từ 485
port.on('open', () => { logColor(`chu_xanh_la Kết nối RS485 chu_vang${config.rs485.comPort}chu_xanh_la baudRate: chu_vang${config.rs485.baudRate}log_reset`) })
var temp = ``

setTimeout(() => {
  const parser = port.pipe(new ByteLength({ length: 1 }))
  parser.on('data', (data) => { // Thu dữ liệu 485
    //  onData(data)
    hex = data.toString('hex')
    temp = temp + data
    // if (hex == `b5` || hex == `fe` || hex == `ff`) { // ngắt khi gặp ký tự kết thúc
    if (hex == `40`) { // ngắt khi gặp ký tự kết thúc
      onData(temp)
      temp = ``
    }
  })
}, 3000)








//ENABLE CORS
app.use((_req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*")
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept")
  // res.header("Cache-Control", "public")
  // res.header("Cache-Control", "no-cache")
  // res.header("Cache-Control", "max-age=3600")
  next()
})
// app.use(express.static(__dirname + '/node_modules'))
app.use('/fontawesome', express.static(__dirname + '/node_modules/@fortawesome/fontawesome-free'));
// app.use('/fortawesome', express.static(__dirname + '/node_modules/@fortawesome'));
app.use(express.static(__dirname + '/views'))
app.set("view engine", "ejs")

app.use(morgan('dev'))
app.use(compression())
app.get(`/`, (_req, res) => { res.render('index') })

/*
 ######## #### ##     ## ######## ########
    ##     ##  ###   ### ##       ##     ##
    ##     ##  #### #### ##       ##     ##
    ##     ##  ## ### ## ######   ########
    ##     ##  ##     ## ##       ##   ##
    ##     ##  ##     ## ##       ##    ##
    ##    #### ##     ## ######## ##     ##
*/
//
// NOTE: TIMER hệ thống
//
function timer() {

}

/*
  ######   #######   ######  ##    ## ######## ########     ####  #######
 ##    ## ##     ## ##    ## ##   ##  ##          ##         ##  ##     ##
 ##       ##     ## ##       ##  ##   ##          ##         ##  ##     ##
  ######  ##     ## ##       #####    ######      ##         ##  ##     ##
       ## ##     ## ##       ##  ##   ##          ##         ##  ##     ##
 ##    ## ##     ## ##    ## ##   ##  ##          ##    ###  ##  ##     ##
  ######   #######   ######  ##    ## ########    ##    ### ####  #######
*/

io.on("connection", (socket) => {
  logColor(`chu_xanh_la Client IP chu_vang ${socket.handshake.address.slice(7)} chu_xanh_la SocketID: chu_vang ${socket.id} log_reset`)


  socket.on("disconnect", () => { // sự kiện mất kết nối
    for (let i = 0; i < json_user.length; i++) {
      if (json_user[i].key == socket.key) { // username mất kết nối
        json_user[i].time = new Date().getTime() // Chốt thời điểm disconnect
        logColor(`chu_do Client disconnected chu_vang ${json_user[i].name} chu_do SocketID chu_vang ${socket.id} log_reset`)
        login.writeFile(json_user)
      }
    }
  })

  socket.on(`list`, () => {
    io.emit(`list`, list_sensor)
  })
  io.emit(`list_com`, listCom)
})
/*
 ##     ## ######## ######## ########
 ##     ##    ##       ##    ##     ##
 ##     ##    ##       ##    ##     ##
 #########    ##       ##    ########
 ##     ##    ##       ##    ##
 ##     ##    ##       ##    ##
 ##     ##    ##       ##    ##
*/
server.listen(config.portserver)
console.clear()
start()
console.log(`---------------------------------------------------------------------------`)
logColor(`chu_xanh_la Khởi động Server cổng: chu_vang ${config.portserver} log_reset`)

/*
 ######## ##     ## ##    ##  ######  ######## ####  #######  ##    ##
 ##       ##     ## ###   ## ##    ##    ##     ##  ##     ## ###   ##
 ##       ##     ## ####  ## ##          ##     ##  ##     ## ####  ##
 ######   ##     ## ## ## ## ##          ##     ##  ##     ## ## ## ##
 ##       ##     ## ##  #### ##          ##     ##  ##     ## ##  ####
 ##       ##     ## ##   ### ##    ##    ##     ##  ##     ## ##   ###
 ##        #######  ##    ##  ######     ##    ####  #######  ##    ##
*/
function start() {

  //common.readTemp(`list_box`, (json) => { list_box = json })
}


/*
 ########     ###    ########    ###    
 ##     ##   ## ##      ##      ## ##   
 ##     ##  ##   ##     ##     ##   ##  
 ##     ## ##     ##    ##    ##     ## 
 ##     ## #########    ##    ######### 
 ##     ## ##     ##    ##    ##     ## 
 ########  ##     ##    ##    ##     ## 
*/
// NOTE:10 Nhận bản tin 485
function onData(data) {
  data = data.replace(/@/g, "");
  data = data.replace(/#/g, "");
  data = data.replace(/\r/g, "");
  data = data.replace(/\n/g, "");
  // data = data.slice(1, -2)
  arr = data.split(',')
  common.time_string((time, unit_time) => {
    if (arr.length == 4) {
      json = {
        type: arr[0],
        no: arr[1],
        val: arr[2],
        unit: arr[3],
        key: `${arr[0]}_${arr[1]}`,
        time: time,
        unit_time: unit_time
      }
      console.log(json);
      common.index_of(list_sensor, "key", `${json.type}_${json.no}`, (i) => {
        if (i == -1) { // sensor mới
          sensor.add(json)
        } else {// sensor cũ
          sensor.edit(json)
        }
      })
      io.emit(`data`, json)

    }

  })
}

/*
######## ##     ## ##    ##    ########  #######  ########    ###    ##
##       ##     ## ###   ##       ##    ##     ##    ##      ## ##   ##
##       ##     ## ####  ##       ##    ##     ##    ##     ##   ##  ##
######   ##     ## ## ## ##       ##    ##     ##    ##    ##     ## ##
##       ##     ## ##  ####       ##    ##     ##    ##    ######### ##
##       ##     ## ##   ###       ##    ##     ##    ##    ##     ## ##
##        #######  ##    ##       ##     #######     ##    ##     ## ########
*/
// NOTE: Slave=>Master Nhận + tổng hợp dữ liệu

